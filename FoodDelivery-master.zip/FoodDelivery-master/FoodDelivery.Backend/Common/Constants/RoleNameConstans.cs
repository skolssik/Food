﻿namespace FoodDelivery.Backennd.Common.Constants;

public class RoleNameConstans
{
    public const string User = nameof(User);
    public const string Manager = nameof(Manager);
}