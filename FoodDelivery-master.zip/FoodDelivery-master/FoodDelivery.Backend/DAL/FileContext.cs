﻿namespace FoodDelivery.Backennd.DAL;

public class FileContext
{
    
}